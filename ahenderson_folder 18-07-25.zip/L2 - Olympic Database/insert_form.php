<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'connect.php';

    function sanitize($input) {
        return htmlspecialchars(trim($input));
    }

    $Name = sanitize($_POST['Name']);
    $Age = sanitize($_POST['Age']);
    $Height = sanitize($_POST['Height']);
    $Weight = sanitize($_POST['Weight']);
    $Team = sanitize($_POST['Team']);
    $Year = sanitize($_POST['Year']);
    $HostCity = sanitize($_POST['HostCity']);
    $Sport = sanitize($_POST['Sport']);
    $Event = sanitize($_POST['Event']);
    $Medal = sanitize($_POST['Medal']);

    $sql = "INSERT INTO olympic (Name, Age, Height, Weight, Team_ID, Year, Host_City_ID, Sport_ID, Event_ID, Medal_ID)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("siiiiiiiii", $Name, $Age, $Height, $Weight, $Team, $Year, $HostCity, $Sport, $Event, $Medal);
        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();
            header("Location: form_page.php?success=1");
            exit();
        } else {
            error_log("Error executing statement: " . $stmt->error);
            echo "Error: " . $stmt->error;
        }
    } else {
        error_log("Error preparing statement: " . $conn->error);
        echo "Error: " . $conn->error;
    }
    $conn->close();
}
?>
