function validateForm() {
    var Name = document.getElementById("Nametext").value;
    var Age = document.getElementById("Agetext").value;
    var Height = document.getElementById("Heighttext").value;
    var Weight = document.getElementById("Weighttext").value;
    var Team = document.getElementById("TeamList").value;
    var Year = document.getElementById("Yeartext").value;
    var HostCity = document.getElementById("HostCityList").value;
    var Sport = document.getElementById("SportList").value;
    var Event = document.getElementById("EventList").value;
    var Medal = document.getElementById("MedalList").value;

    // Validate Name
    var namePattern = /^[A-Za-z\s]+$/; // Regular expression to allow only letters and spaces
    if (Name.trim() === "" || !namePattern.test(Name)) {
        alert("Name must be filled out and contain only letters and spaces!");
        return false;
    }

    // Validate Age
    if (Age === "" || isNaN(Age) || Age < 10 || Age > 100) {
        alert("Please enter a valid age between 10 and 100.");
        return false;
    }

    // Validate Height
    if (Height === "" || isNaN(Height) || Height < 100 || Height > 250) {
        alert("Please enter a valid height between 100 and 250 cm.");
        return false;
    }

    // Validate Weight
    if (Weight === "" || isNaN(Weight) || Weight < 30 || Weight > 200 kg) {
        alert("Please enter a valid weight between 30 and 200 kg.");
        return false;
    }

    // Validate Team (Ensure a team is selected)
    if (Team === "") {
        alert("Please select a team.");
        return false;
    }
    
    // Define valid year-host city pairs
    const validPairs = {
        2008: "Beijing",
        2012: "London",
        2016: "Rio de Janeiro"
    };

    // Convert the Year to a number
    var YearNumber = parseInt(Year);

    // Get the selected city's text value from the dropdown and trim whitespace
    const cityText = document.getElementById("HostCityList").options[document.getElementById("HostCityList").selectedIndex].text.trim();

    // Validate Year and City pair
    if (validPairs[YearNumber] && validPairs[YearNumber] !== cityText) {
        alert("Invalid year or host city. Please enter a valid year and corresponding host city. 2008: Beijing, 2012: London, and 2016: Rio de Janeiro");
        return false;
    }

	    // Validate Year
    if (Year === "" || isNaN(Year) || Year < 2000 || Year > 3000) {
        alert("Please enter a valid year between 2000 and 3000.");
        return false;
    }
	
    // Validate Host City (Ensure a host city is selected)
    if (HostCity === "") {
        alert("Please select a host city.");
        return false;
    }
	
    // Validate Sport (Ensure a sport is selected)
    if (Sport === "") {
        alert("Please select a sport.");
        return false;
    }

    // Validate Event (Ensure an event is selected)
    if (Event === "") {
        alert("Please select an event.");
        return false;
    }

    // Validate Medal (Ensure a medal type is selected)
    if (Medal === "") {
        alert("Please select a medal type.");
        return false;
    }

    // If all validations pass, return true to submit the form
    return true;
}
