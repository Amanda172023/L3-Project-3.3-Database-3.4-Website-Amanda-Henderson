<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>BrightPath</title>
		
		<!-- Stylesheets -->
		<link href="css/style(1)_start_page.css" rel="stylesheet" type="text/css">
		
		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
	  	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />
		
		<!-- Favicon -->
    	<link rel="icon" type="image/x-icon" href="images/logo.png">
		
	</head>
	<body>
	  <div class="container">
    	<div class="logo">
      	<span>BrightPath</span>
     	<img src="images/logo.png" alt="logo" class="bulb-img">
	</div>

		<div class="user-sections">
		  <div class="user-box">
			<h2>Student</h2>
			<button onclick="location.href='(3a)_login_student.php'">Login</button>
			<button onclick="location.href='(2a)_register_student.php'">Register</button>
		  </div>

		  <div class="user-box">
			<h2>Teacher</h2>
			<button onclick="location.href='(3b)_login_teacher.php'">Login</button>
			<button onclick="location.href='(2b)_register_teacher.php'">Register</button>
		  </div>
		</div>
		<footer>
		  BrightPath Learning System
		</footer>
	  </div>
	</body>
	</html>