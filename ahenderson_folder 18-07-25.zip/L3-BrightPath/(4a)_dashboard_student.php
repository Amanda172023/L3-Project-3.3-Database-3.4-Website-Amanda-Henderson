<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BrightPath - Student Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/style(4)_dashboard_page.css" />
  <link rel="icon" type="image/x-icon" href="images/logo.png">
</head>
<body>
    <!-- Logo Section -->
    <div class="logo">
      <span>BrightPath</span>
      <img src="images/logo.png" alt="logo" class="bulb-img">
    </div>

    <!-- Navigation -->
    <nav class="navbar">
      <a class="activenav" href="(4a)_dashboard_student.php">Dashboard</a>
      <a href="(5a)_timeline_student.php">Timeline</a>
      <a href="(6)_quiz_student.php">Quizzes</a>
    </nav>
<div class="container">
    <!-- Page Heading -->
    <h1 class="dashboard-title">Your Dashboard</h1>

    <!-- Grid Layout -->
    <div class="dashboard-grid">
      <div class="left-column">
        <div class="card text-card">
          <h3>Welcome to Mrs Thomas</h3>
          <p>I’m Mrs Thomas, and I’m so excited to be your teacher this year. In our class, we ask questions, try new things, and support each other. Check here regularly for updates, resources, and what’s coming up next. Let’s make this a great year together!</p>
        </div>

        <div class="card user-info">
          <h3>User Information</h3>
          <div class="avatar"></div>
          <p>Student Name<br>Email or ID</p>
        </div>

        <div class="card badges-earned">
          <h3>Badges Earned</h3>
          <div class="badges">
            <div class="badge">🏅</div>
            <div class="badge">🏅</div>
            <div class="badge">🏅</div>
          </div>
        </div>

        <div class="card assignments">
          <h3>Upcoming Assignments</h3>
          <div class="assignment">Assignment 1 <div class="bar"></div></div>
          <div class="assignment">Assignment 2 <div class="bar"></div></div>
        </div>
      </div>

      <div class="right-column">
        <div class="card quizzes">
          <h3>Quizzes</h3>
          <div class="quiz-grid">
            <div class="quiz-card">
              <img src="images/quiz.jpg" alt="quiz">
              <p>Quiz Title</p>
              <div class="progress-bar"><div class="progress" style="width: 70%"></div></div>
            </div>
            <!-- Duplicate above quiz-card for more -->
          </div>
        </div>

        <div class="card search">
          <h3>Search</h3>
          <input type="text" placeholder="Search...">
        </div>

        <div class="card timeline">
          <h3>Timeline</h3>
          <p>Recent activity and updates will show here.</p>
        </div>
      </div>
    </div>

    <footer>BrightPath Learning System</footer>
  </div>
</body>
</html>
