<?php

	//PRINT A STATEMENT THAT INPUT HAS BEEN LOADED INTO DATABASE
	print("<h2>Loaded</h2>");
	
	//CONNECT TO OUR DATABASE
	require_once ("connect.php");

	$Title = $_REQUEST ['title'];
	$Author = $_REQUEST ['lname'];
	$Image = $_REQUEST ['bimage'];
	$Genre = $_REQUEST ['bgenre'];
	$Rating = $_REQUEST ['brating'];
	$Review = $_REQUEST ['breview'];

	$sql = "INSERT INTO Books (Title, Author, Image, Genre, Rating, Review)
			VALUES ('$Title','$Author','$Image','$Genre','$Rating', '$Review')";
	
	if ($conn->query($sql) === TRUE){
		echo "New record created successfully";
	}
	else{
		echo"Error: " . $sql. "<br>" . $conn->error;	
	}

	echo "<script>location.herf='books/php'</script>";

?>