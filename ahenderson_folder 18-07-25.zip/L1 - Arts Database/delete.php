<?php

	//connect to database
	require_once 'connect.php';

	//store ID request from Events Page Delete Button into php variable
	$ID = $_REQUEST ['ID'];

	//SQL request
	$sql = "DELETE FROM Arts WHERE ID = '" . $ID . "'";

	//Confirm whether query has been sucessful or not
	//Successful 
	if (mysqli_query ($conn, $sql)) {
		print ("Deleted");
	}
	else{
		print ("Falied") ;
	}

	echo "<script>location.href='Events.php'</script>)";
?>