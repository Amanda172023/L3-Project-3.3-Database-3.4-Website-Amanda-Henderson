<!DOCTYPE html>
<html lang="en">
	<head>
	  <meta charset="UTF-8" />
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	  
	<title>BrightPath - Login Teacher</title>

		<!-- Stylesheets -->
		<link href="css/style(3)_login_page.css" rel="stylesheet" type="text/css">

	  <!-- Google Fonts -->
	  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
	  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />

	  <!-- Favicon -->
	  <link rel="icon" type="image/x-icon" href="images/logo.png">

	</head>
	<body>
		  <div class="container">
			<!-- Logo -->
			<div class="logo">
			  <span>BrightPath</span>
			  <img src="images/logo.png" alt="logo" class="bulb-img">
			</div>

			<!-- Back Button -->
			<a href="(1)_start_page.php" class="back-button">← Back to Start Page</a>

			<!-- Login Form -->
			<div class="login-box">
			  <h2>Login - Teacher</h2>

			  <div class="input-group">
				<input type="text" placeholder="Username">
			  </div>

			  <div class="input-group">
				<input type="password" placeholder="Password">
			  </div>

			  <a href="(4b)_dashboard_teacher.php" class="login-btn">Login</a>

			  <p class="register-text">Don’t have an account? <a href="(2b)_register_teacher.php">Register</a></p>
			</div>

			<!-- Footer -->
			<footer>BrightPath Learning System</footer>
		  </div>
	</body>
</html>
