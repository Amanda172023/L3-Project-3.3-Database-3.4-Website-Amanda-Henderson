<?php					
	
	<!-- 

				PHP CODE HERE FROM LESSON 8

				  ______ ______
				_/      Y      \_
			   // ~~ ~~ | ~~ ~  \\
			  // ~ ~ ~~ | ~~~ ~~ \\      Original Unknown
			 //________.|.________\\     Diddled by David Issel
			`----------`-'----------'


		-->
?>