<?php include ("topbit.php") ?>

    <nav>
            
        <div id="menuItems">
            <p><a href="index.php">Home</a></p>
            <p><a class="active" href="books.php">Books</a></p>
        </div>

    </nav>

	<!-- ______________________ CONTENT PER PAGE ______________________ -->
    <main class="content">

		<!-- PHP CODE TO CONNECT TO DATABASE-->
		<?php
			
			require_once 'connect.php';
			
			//SQL STATEMENT TO FETCH EVERYTHING (*) FROM THE B TABLE
			$sql = "SELECT * FROM Books";
			
			//ESTABLISH CONNECTION WITH $conn & QUERY THE $sql STATEMENT 
			$result = $conn->query($sql);
		?>
		
		<section id="bookList">
			<h2>Books</h2>
			<!-- TABLE CONSTRUCTION-->
			<table>
				<tr>
					<th>Title</th>
					<th>Image</th>
					<th>Author</th>
					<th>Genre</th>
					<th>Rating</th>
					<th>Review</th>
				</tr>
				
				<!-- PHP CODE TO FETCH DATA FROM ROWS-->
				<?php 	// LOOP TILL END OF DATA
					while($rows=$result->fetch_assoc())
					{
				?>
						<tr>
							<!-- FETCHING DATA FROM EACH
								ROW OF EVERY COLUMN-->
							<td><?php echo $rows['Title'];?></td>
							<td><?php echo '<img src="' . $rows['Image'] . '" height="150" width="150">';?></td>
							<td><?php echo $rows['Author'];?></td>
							<td><?php echo $rows['Genre'];?></td>
							<td><?php echo $rows['Rating'];?></td>
							<td><?php echo $rows['Review'];?></td>
						</tr>
				<?php
					}
				 ?>
			</table>
		</section>
		
		<hr>
		
		<div class="submit">
		
			<h2>Add a new Book</h2>
			
			<form action="insert_form.php" method="post">
				
				<label for="btitle">Book Title:</label>
				<input type="text" name="title" required>
				
				<label for="bauthor">Author:</label>
				<input type="text" name="lname" required>
				
				<label for="bimage">Image File Location:</label>
				<input type="text" name="bimage" required>
			
				<label for="bgenre">Genre:</label>
				<input type="text" name="bgenre" required>
				
				<label for="brating">Rating:</label>
				<select name="brating" required>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
				</select>
				
				<label for="breview">Review:</label>
				<input type="text" name="breview" required>
				
				<input type="submit" value="Submit">
			</form>

		</div>

    </main>

<?php include ("bottombit.php") ?>