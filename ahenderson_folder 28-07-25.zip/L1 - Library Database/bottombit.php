    <footer>
        <p class="centre">© 2021 James Hargest College.</p>
    </footer>

	</div><!--close container div-->

</body>

</html>