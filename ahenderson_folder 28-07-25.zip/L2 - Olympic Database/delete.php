<?php
	//connect to database
	require_once 'connect.php';

	//store ID request from Events Page Delete Button into php variable
	$ID = $_REQUEST ['ID'];

	//SQL request
	$sql = "DELETE FROM olympic WHERE ID = '" . $ID . "'";

	//Confirm whether query has been sucessful or not
	//Successful 
	if (mysqli_query ($conn, $sql)) {
		print ("Data Successfully Deleted");
	}
	else{
		print ("Falied") ;
	}
	// Relocate to database_page.php
	echo "<script>location.href='database_page.php'</script>";
?>