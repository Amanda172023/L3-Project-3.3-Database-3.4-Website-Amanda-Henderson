<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Olympics - Female Medal Winners</title>

		<!-- Stylesheets -->
		<link href="css/style.css" rel="stylesheet" type="text/css" />
		<link href="css/database.css" rel="stylesheet" type="text/css" />
		<link href="css/color_blind_mode" rel="stylesheet" type="text/css">

		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100..900&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c&family=Nanum+Gothic&display=swap" rel="stylesheet">

		<!-- Favicon -->
		<link rel="icon" type="image/x-icon" href="images/logo.png">
	</head>

	<body>

		<!-- Header -->
		<header>
			<img src="images/logo.png" width="350" height="230" alt="Logo">
			<h1>Olympics</h1>
			<h2>Female Medal Winners</h2>
		</header>
		
		<!-- Navigation -->
		<ul class="nav">
		  <a href="index.php">Home</a>
		  <a class="activenav" href="database_page.php">Database</a>
		  <a href="form_page.php">Form</a>
		</ul>
		
    	<div class="content">

			<?php
			require_once 'connect.php';
			
			$search = isset($_POST['search']) ? $_POST['search'] : '';

			// Fetch the sort parameters from the GET request
			$column = isset($_GET['column']) ? $_GET['column'] : 'Name';
			$direction = isset($_GET['direction']) ? $_GET['direction'] : 'ASC';

			// SQL statement to fetch everything (*) with proper joins and sorting
			$sql = "SELECT * 
			FROM olympic
			JOIN event ON olympic.Event_ID = event.Event_ID
			JOIN host_city ON olympic.Host_City_ID = host_city.Host_City_ID
			JOIN medal ON olympic.Medal_ID = medal.Medal_ID
			JOIN sport ON olympic.Sport_ID = sport.Sport_ID
			JOIN team ON olympic.Team_ID = team.Team_ID
			WHERE Name LIKE '%$search%'
			OR Age LIKE '%$search%'
			OR Height LIKE '%$search%'
			OR Weight LIKE '%$search%'
			OR Team LIKE '%$search%'
			OR Year LIKE '%$search%'
			OR Host_City LIKE '%$search%'
			OR Sport LIKE '%$search%'
			OR Event LIKE '%$search%'
			OR Medal LIKE '%$search%'
			ORDER BY $column $direction
			";
			
			// ESTABLISH CONNECTION WITH $conn & QUERY THE $sql STATEMENT
			$result = $conn->query($sql);
			?>
			
			<form method="GET" action="" id="sortForm">
				<label for="column">Sort by Type:</label>
				<select name="column" id="column" onchange="saveSortPreferences()">
					<option value="Name" <?php if ($column == 'Name') echo 'selected'; ?>>Name</option>
					<option value="Age" <?php if ($column == 'Age') echo 'selected'; ?>>Age</option>
					<option value="Height" <?php if ($column == 'Height') echo 'selected'; ?>>Height</option>
					<option value="Weight" <?php if ($column == 'Weight') echo 'selected'; ?>>Weight</option>
					<option value="Team" <?php if ($column == 'Team') echo 'selected'; ?>>Team</option>
					<option value="Year" <?php if ($column == 'Year') echo 'selected'; ?>>Year</option>
					<option value="Host_City" <?php if ($column == 'Host_City') echo 'selected'; ?>>Host City</option>
					<option value="Sport" <?php if ($column == 'Sport') echo 'selected'; ?>>Sport</option>
					<option value="Event" <?php if ($column == 'Event') echo 'selected'; ?>>Event</option>
					<option value="Medal" <?php if ($column == 'Medal') echo 'selected'; ?>>Medal</option>
				</select>
				<label for="direction">Change Order:</label>
				<select name="direction" id="direction" onchange="saveSortPreferences()">
					<option value="ASC" <?php if ($direction == 'ASC') echo 'selected'; ?>>Ascending</option>
					<option value="DESC" <?php if ($direction == 'DESC') echo 'selected'; ?>>Descending</option>
				</select>
				<br>
			</form>

			<form method="POST" action="database_page.php">
				<div class="col">
					<input type="text" name="search" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search); ?>">
					<button type="submit" name="save" class="btn btn-primary">Search</button>
				</div>
			</form>
			
			<br>

			<?php
			echo '<section id="OlympicsList" class="flex-container">';
			// LOOP UNTIL THE END OF DATA
			if ($result->num_rows > 0) {
            	while ($row = $result->fetch_assoc()) {
                	echo '<article>';
						echo '<p><span id="title">Name: </span><span>' . $row["Name"] . '</span></p>';
						echo '<p><span id="title">Age: </span><span>' . $row["Age"] . '</span></p>';
						echo '<p><span id="title">Height: </span><span>' . $row["Height"] . '</span></p>';
						echo '<p><span id="title">Weight: </span><span>' . $row["Weight"] . '</span></p>';
						echo '<p><span id="title">Team: </span><span>' . $row["Team"] . '</span></p>';
						echo '<p><span id="title">Year: </span><span>' . $row["Year"] . '</span></p>';
						echo '<p><span id="title">Host City: </span><span>' . $row["Host_City"] . '</span></p>';
						echo '<p><span id="title">Sport: </span><span>' . $row["Sport"] . '</span></p>';
						echo '<p><span id="title">Event: </span><span>' . $row["Event"] . '</span></p>';
						echo '<p><span id="title">Medal: </span><span>' . $row["Medal"] . '</span></p>';
						echo "<a class='delete-link' href='delete.php?ID=" . $row['ID'] . "'><button class='btnDelete'>DELETE</button></a>";
                    echo '</article>';
                        }
                    }
					else {
						echo '<h2 class="olympicHeading">No results found! Please refresh and try again!</h2>';
					}
			echo '</section>';
			?>
		
    	</div>
		
		<!-- Footer -->
		<footer>
			<h5>Author : Amanda Henderson 
				<br>
				Mailto: 21030@jhc.school.nz
			</h5>
		 </footer> 
		
		
		<!-- JavaScript to handle local storage -->
		<script>
			function saveSortPreferences() {
				const column = document.getElementById('column').value;
				const direction = document.getElementById('direction').value;
				localStorage.setItem('column', column);
				localStorage.setItem('direction', direction);
				document.getElementById('sortForm').submit();
			}

			document.addEventListener('DOMContentLoaded', (event) => {
				const savedColumn = localStorage.getItem('column');
				const savedDirection = localStorage.getItem('direction');
				if (savedColumn) {
					document.getElementById('column').value = savedColumn;
				}
				if (savedDirection) {
					document.getElementById('direction').value = savedDirection;
				}
			});
		</script>
	</body>
</html>