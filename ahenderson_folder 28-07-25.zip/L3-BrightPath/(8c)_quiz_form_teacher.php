<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BrightPath - Teacher Create Quizzes</title>
  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/style(8)_teacher_quiz_page.css" />
  <link rel="icon" type="image/x-icon" href="images/logo.png">
</head>
<body>
  <!-- Logo Section -->
  <div class="logo">
    <span>BrightPath</span>
    <img src="images/logo.png" alt="logo" class="bulb-img">
  </div>

  <!-- Navigation Bar -->
  <nav class="navbar">
    <a href="(4b)_dashboard_teacher.php">Dashboard</a>
    <a href="(5b)_timeline_teacher.php">Timeline</a>
    <a class="activenav" href="(8a)_quiz_list_teacher.php">Quizzes</a>
  </nav>

<!-- Sidebar -->
<div class="side-nav">
  <ul>
    <li><a href="(8a)_quiz_list_teacher.php">Quizzes</a></li>
	<li><a class="activenav" href="(8c)_quiz_form_teacher.php">Create New Quiz</a></li>
	<li><a href="(8d)_quiz_results_teacher.php">Student Results</a></li>
  </ul>
</div>
	
	<div class="container">
    <!-- Page Heading -->
    <h1 class="dashboard-title">Create New Quiz</h1>
		
	</div>
  <!-- Footer -->
  <footer>
    BrightPath Learning System
  </footer>
</body>
</html>
