<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>BrightPath - Register Teacher</title>

  <!-- Stylesheets -->
  <link href="css/style(2)_register_page.css" rel="stylesheet" type="text/css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="images/logo.png">
</head>
<body>
  <div class="container">
    <!-- Logo -->
    <div class="logo">
      <span>BrightPath</span>
      <img src="images/logo.png" alt="logo" class="bulb-img">
    </div>

    <!-- Back Button -->
    <a href="(1)_start_page.php" class="back-button">← Back to Start Page</a>

    <!-- Register Form -->
    <div class="login-box">
      <h2>Register - Teacher</h2>

      <div class="input-group">
        <input type="text" placeholder="First Name">
      </div>

      <div class="input-group">
        <input type="text" placeholder="Last Name">
      </div>

      <div class="input-group">
        <input type="text" placeholder="Username">
      </div>

      <div class="input-group">
        <input type="password" placeholder="Password">
      </div>

      <div class="input-group">
        <input type="password" placeholder="Confirm Password">
      </div>

      <a href="(4b)_dashboard_teacher.php" class="login-btn">Register</a>

      <p class="register-text">Already have an account? <a href="(3b)_login_teacher.php">Login</a></p>
    </div>

    <!-- Footer -->
    <footer>BrightPath Learning System</footer>
  </div>
</body>
</html>
