<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    
    <!-- Meta Tags -->
    <meta name="description" content="games, apps">
    <meta name="keywords" content="Game, App Database, games, apps, ratings">
    
    <title>Game Database</title>
    
    <!-- Fonts and Stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Lato%7cUbuntu" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/data_style.css"> <!-- Custom style sheet -->
</head>

<body>
    <p class="message">Eek! Your browser does not support grid. 
    Please upgrade your system.</p>
    
    <div class="wrapper">
        
        <!-- Logo / Small Image -->
        <div class="box logo">
            <a href="index.php"><img src="images/logo.png" width="261" height="150" alt="Dice"></a>
        </div>
        
        <div class="box banner">
            <h1>Games Database</h1>
        </div> <!-- / banner -->
        
        <div class="box main">

            <!-- PHP and Database Content -->
            <?php
                // PHP CODE TO CONNECT TO DATABASE
                require_once 'connect.php';

                // SQL STATEMENT TO FETCH EVERYTHING (*) FROM DATABASE
                $sql = "SELECT * FROM games_sales";

                // ESTABLISH CONNECTION WITH $conn & QUERY THE $sql STATEMENT
                $result = $conn->query($sql);
            ?>

            <section id="games_sales">

                <?php
                    echo '<section id="GamesList" class="flex-container">';
                    // LOOP UNTIL THE END OF DATA
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<article>';
							echo '<h1 class="gamesHeading">' .$row['Rank'] . '</h1>';
							echo '<p><span id="title">Name: </span><span>' . $row["Name"] . '</span></p>';
							echo '<p><span id="title">Year: </span><span>' . $row["Year"] . '</span></p>';
							echo '<p><span id="title">Platform ID: </span><span>' . $row["Platform_ID"] . '</span></p>';
							echo '<p><span id="title">Genre ID: </span><span>' . $row["Genre_ID"] . '</span></p>';
							echo '<p><span id="title">Publisher ID: </span><span>' . $row["Publisher_ID"] . '</span></p>';
							echo '<p><span id="title">NA Sales: </span><span>' . $row["NA_Sales"] . '</span></p>';
							echo '<p><span id="title">EU Sales: </span><span>' . $row["EU_Sales"] . '</span></p>';
							echo '<p><span id="title">JP Sales: </span><span>' . $row["JP_Sales"] . '</span></p>';
							echo '<p><span id="title">Other Sales: </span><span>' . $row["Other_Sales"] . '</span></p>';
							echo '<p><span id="title">Global Sales: </span><span>' . $row["Global_Sales"] . '</span></p>';
							echo "<a class='delete-link' href='delete.php?ID=" . $row['ID'] . "'><button class='btnDelete'>DELETE</button></a>";
                            echo '</article>';
                        }
                    }
                    echo '</section>';
                ?>
            </section>

            <br>
            <br>
            <div class="submit">
                <h1>Add a New Game</h1>
                <form action="insert_form.php" method="post">
                    <label for="rank">Rank:</label>
                    <input type="number" name="Rank" id="rank" required>

                    <label for="name">Name:</label>
                    <input type="text" name="Name" id="name" required>

                    <label for="year">Year:</label>
                    <input type="number" name="Year" id="year" required>

                    <label for="platform_id">Platform ID:</label>
                    <input type="number" name="Platform_ID" id="platform_id" required>

                    <label for="genre_id">Genre ID:</label>
                    <input type="number" name="Genre_ID" id="genre_id" required>

                    <label for="publisher_id">Publisher ID:</label>
                    <input type="number" name="Publisher_ID" id="publisher_id" required>

                    <label for="na_sales">North American Sales:</label>
                    <input type="number" step="0.01" name="NA_Sales" id="na_sales" required>

                    <label for="eu_sales">Europe Sales:</label>
                    <input type="number" step="0.01" name="EU_Sales" id="eu_sales" required>

                    <label for="jp_sales">Japan Sales:</label>
                    <input type="number" step="0.01" name="JP_Sales" id="jp_sales" required>

                    <label for="other_sales">Other Sales:</label>
                    <input type="number" step="0.01" name="Other_Sales" id="other_sales" required>

                    <label for="global_sales">Global Sales:</label>
                    <input type="number" step="0.01" name="Global_Sales" id="global_sales" required>

                    <input type="submit" value="Submit">
                </form>
            </div>
        </div> <!-- / main -->
        
        <div class="box side">
            <h2>Search Area</h2>
            <p>This is where the search area goes</p>
        </div> <!-- / side -->
        
        <div class="box footer">
            <p>Mrs Sarah Greeff 2020</p>
        </div> <!-- / footer -->
        
    </div> <!-- / wrapper -->

    <script>
        function redirectToeventsPage() {
            window.location.href = 'games.php';
        }
    </script>
</body>
</html>
