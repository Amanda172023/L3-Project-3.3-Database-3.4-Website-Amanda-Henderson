<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BrightPath - Timeline</title>
  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/style(5)_timeline_page.css" />
  <link rel="icon" type="image/x-icon" href="images/logo.png">
</head>
<body>
  <!-- Logo -->
  <div class="logo">
    <span>BrightPath</span>
    <img src="images/logo.png" alt="logo" class="bulb-img">
  </div>

  <!-- Navigation -->
  <nav class="navbar">
    <a href="(4a)_dashboard_student.php">Dashboard</a>
    <a class="activenav" href="(5a)_timeline_student.php">Timeline</a>
    <a href="(6)_quiz_student.php">Quizzes</a>
  </nav>

  <!-- Main Container -->
  <div class="container">
    <h1 class="timeline-title">Timeline</h1>

    <!-- Calendar Navigation -->
    <div class="calendar-nav">
      <button class="arrow">&lt;</button>
      <h2>July 2025</h2>
      <button class="arrow">&gt;</button>
      <button class="add-button">+</button>
    </div>

    <div class="timeline-layout">
      <!-- Calendar -->
      <div class="calendar">
        <div class="weekdays">
          <div>Monday</div><div>Tuesday</div><div>Wednesday</div>
          <div>Thursday</div><div>Friday</div><div>Saturday</div><div>Sunday</div>
        </div>
        <div class="days">
          <!-- Sample day boxes (you'd dynamically fill this) -->
          <div class="day"></div><div class="day"></div><div class="day">2<div class="event"></div></div>
          <div class="day">3</div><div class="day">4</div><div class="day">5</div><div class="day">6</div>
          <div class="day">7</div><div class="day">8</div><div class="day">9</div>
          <div class="day">10<div class="event"></div></div>
          <!-- Continue for rest of month -->
        </div>
      </div>

      <!-- Upcoming Sidebar -->
      <div class="upcoming">
        <h3>Upcoming</h3>
        <div class="upcoming-item"></div>
        <div class="upcoming-item"></div>
        <div class="upcoming-item"></div>
        <div class="upcoming-item"></div>
        <div class="upcoming-item"></div>
      </div>
    </div>
    <footer>BrightPath Learning System</footer>
  </div>
</body>
</html>
