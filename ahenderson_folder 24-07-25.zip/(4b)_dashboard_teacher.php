<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BrightPath - Teacher Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/style(4)_dashboard_page.css" />
  <link rel="icon" type="image/x-icon" href="images/logo.png">
</head>
<body>
  <!-- Logo Section -->
  <div class="logo">
    <span>BrightPath</span>
    <img src="images/logo.png" alt="logo" class="bulb-img">
  </div>

  <!-- Navigation -->
  <nav class="navbar">
    <a class="activenav" href="(4b)_dashboard_teacher.php">Dashboard</a>
    <a href="(5b)_timeline_teacher.php">Timeline</a>
    <a href="(8a)_quiz_list_teacher.php">Quizzes</a>
  </nav>

  <div class="container">
    <!-- Page Heading -->
    <h1 class="dashboard-title">Your Dashboard</h1>

    <div class="dashboard-grid">
      <!-- Left Column -->
      <div class="left-column">
        <div class="card text-card">
          <h3>Edit Student Text Card</h3>
          <p>Click here to review and edit individual student writing samples.</p>
        </div>

        <div class="card user-info">
          <h3>User Information</h3>
          <div class="avatar"></div>
          <p>Teacher Name<br>Email or ID</p>
        </div>

        <div class="card quizzes">
          <h3>Quizzes Assigned</h3>
          <div class="quiz-grid">
            <div class="quiz-card">
              <img src="images/quiz.jpg" alt="quiz">
              <p>Quiz A</p>
              <div class="progress-bar"><div class="progress" style="width: 100%"></div></div>
            </div>
            <div class="quiz-card">
              <img src="images/quiz.jpg" alt="quiz">
              <p>Quiz B</p>
              <div class="progress-bar"><div class="progress" style="width: 50%"></div></div>
            </div>
            <div class="quiz-card">
              <img src="images/quiz.jpg" alt="quiz">
              <p>Quiz C</p>
              <div class="progress-bar"><div class="progress" style="width: 80%"></div></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column -->
      <div class="right-column">
        <div class="card assignments">
          <h3>Student Progress</h3>
          <div class="assignment">Student 1 <div class="bar" style="width: 90%"></div></div>
          <div class="assignment">Student 2 <div class="bar" style="width: 70%"></div></div>
          <div class="assignment">Student 3 <div class="bar" style="width: 50%"></div></div>
        </div>

        <div class="card search">
          <h3>Search</h3>
          <input type="text" placeholder="Search students...">
        </div>

        <div class="card timeline">
          <h3>Timeline</h3>
          <p>View upcoming activities, milestones, and submission dates.</p>
        </div>
      </div>
    </div>

    <footer>BrightPath Learning System</footer>
  </div>
</body>
</html>
