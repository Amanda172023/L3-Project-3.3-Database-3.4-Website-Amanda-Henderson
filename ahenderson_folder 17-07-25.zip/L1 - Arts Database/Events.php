<html>
  <head>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  
  	<!--────────────────Title───────────────-->
    <title>Arts at JHC - Events</title>

    <!--────────────────Style Sheets───────────────-->
  	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link href="css/style-responsive.css" rel="stylesheet" type="text/css" />
	<link href="css/database.css" rel="stylesheet" type="text/css" />
	
    <!--────────────────Color Blind Mode Script───────────────-->
	<script>
		function toggleColorBlindMode() {
			var body = document.getElementsByTagName("body")[0];
			body.classList.toggle("color-blind-mode");

			var isEnabled = body.classList.contains("color-blind-mode");
			localStorage.setItem("colorBlindModeEnabled", isEnabled);
		}

		document.addEventListener("DOMContentLoaded", function() {
			var isEnabled = localStorage.getItem("colorBlindModeEnabled") === "true";
			var body = document.getElementsByTagName("body")[0];
			if (isEnabled) {
				body.classList.add("color-blind-mode");
			}
		});
	</script>
    
    <!--────────────────Fonts───────────────-->
    <link href='https://fonts.googleapis.com/css?family=Alata' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Cutive' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=B612' rel='stylesheet'>
    
    <!--────────────────Favicon───────────────-->
    <link rel="icon" type="image/x-icon" href="images/Logo.png">

    <script src="script.js"></script>
  </head>
	
	<body>

		<!--────────────────Header───────────────-->
		<header>
		  <img id="Header Photo" src="images/Header Photo.jpg" height="75%" width="99.65%">
		</header>
		<!--────────────────Nav───────────────-->
		<ul class="nav">
		  <a href="index.html">Home</a>
		  <a href="AboutUs.html">About Us</a>
		  <a class="activenav" href="Events.html">Events</a>
		  <a href="ContactUs.html">Contact Us</a>
		</ul>
	<!--────────────────Container───────────────-->
		<div class="container"> <!-- Sometimes called class="wrapper" -->

		</div>

		  <!--────────────────Content───────────────-->
		  <div class="content">

			  <!-- PHP CODE TO CONNECT TO DATABASE-->
			  <?php
				require_once 'connect.php';

				// SQL STATEMENT TO FETCH EVERYTHING (*) FROM THE Arts TABLE
				$sql = "SELECT * FROM Arts ORDER BY Title";

				// ESTABLISH CONNECTION WITH $conn & QUERY THE $sql STATEMENT
				$result = $conn->query($sql);
				?>

				<h1>Events</h1>

				<?php
				echo '<section id="ArtsList" class="flex-container">';
				// LOOP UNTIL THE END OF DATA
				if ($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {
						echo '<article>';
						echo '<h6><strong>' . $row['Title'] . '</strong></h6>';
						echo '<p><strong>Type:</strong> <span>' . $row['Type'] . '</span></p>';
						echo '<p><strong>Competition:</strong> <span>' . $row['Competition'] . '</span></p>';
						echo '<p><strong>Teacher:</strong> <span>' . $row['Teacher'] . '</span></p>';
						echo '<p><strong>Term:</strong> <span>' . $row['Term'] . '</span></p>';
						echo '<p><strong>Description:</strong> <span>' . $row['Description'] . '</span></p>';

						echo "<a class='delete-link' href='delete.php?ID=" . $row['ID'] . "'><button10 class='bntDelete'>DELETE</button10></a>";


						echo '</article>';
					}
				}
				echo '</section>';
				?>

				<br>
				<br>
				<div class="submit">
					<h1>Add a New Event</h1>
					<form action="insert_form.php" method="post">
						<label for="bTitle">Title:</label>
						<input type="text" name="Title" required>

						<label for="bType">Type:</label>
						<input type="text" name="bType" required>

						<label for="bCompetition">Competition:</label>
						<input type="text" name="bCompetition" required>

						<label for="bTeacher">Teacher:</label>
						<input type="text" name="bTeacher" required>

						<label for="bTerm">Term:</label>
						<input type="text" name="bTerm" required>

						<label for="bDescription">Description:</label>
						<input type="text" name="bDescription" required>

						<input type="submit" value="Submit">
					</form>
				</div>
	 
			  <script>
				  function redirectToeventsPage() {
					  window.location.href = 'Events.php';
				  }
				</script>

		  <!--────────────────Color Blind Mode───────────────-->
		  <button onclick="toggleColorBlindMode()">Toggle Color Blind Mode</button>
		  <br>
		  <br>
		  <!--────────────────Footer───────────────-->
		  <footer>
			<br>
			<h5>James Hargest College</h5>
			<h5>Author : Amanda Henderson - Mailto: 21030@jhc.school.nz</h5>
			<br>
		  </footer> 
		</div>
	</body>
</html>