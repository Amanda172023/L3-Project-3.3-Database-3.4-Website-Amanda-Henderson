<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Olympics - Female Medal Winners</title>

    <!-- Stylesheets -->
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/color_blind_mode.css" rel="stylesheet" type="text/css">
    <link href="css/form.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c&family=Nanum+Gothic&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="images/logo.png">

    <!-- JavaScript for Form Validation -->
    <script type="text/javascript" src="js/insert_olympics.js"></script>
	
	<?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <script>
        alert("New record added successfully!");
    </script>
<?php endif; ?>

</head>
<body>

<!-- Header -->
    <header class="other_header">
        <img src="images/logo.png" width="100" height="230" alt="Logo" class="smaller_logo">
        <div class="header_text">
            <h1>Olympics</h1>
            <h2>Female Medal Winners</h2>
        </div>
    </header>

<!-- Navigation -->
		<ul class="nav">
			<a href="index.php">Home</a>
			<a href="database_page.php">Database</a>
			<a class="activenav" href="form_page.php">Form</a>
		</ul>

<!-- Color Blind Mode Button -->
<button class="color_blind_button" onclick="toggleColorBlindMode()">Toggle Color Blind Mode</button>

<!-- Content Section -->
<div class="content">
    <div class="submit">
        <h2>Add a New Athlete</h2>
        <form class="addOlympic" action="insert_form.php" method="post" name="insert" onsubmit="return validateForm()">
            <label for="Name" id="Form_Label">Name:</label>
			<input type="text" id="Nametext" name="Name" required>

            <label for="Age" id="Form_Label">Age:</label>
            <input type="number" id="Agetext" name="Age" min="10" max="100" required>

            <label for="Height" id="Form_Label">Height (cm):</label>
            <input type="number" id="Heighttext" name="Height" min="100" max="250" step="0.1" required>

            <label for="Weight" id="Form_Label">Weight (kg):</label>
            <input type="number" id="Weighttext" name="Weight" min="30" max="200" step="0.1" required>

            <label for="Team" id="Form_Label">Team:</label>
            <select name='Team' id='TeamList' required>
                <?php
                require_once 'connect.php';

                // Fetch teams from the database
                $sql = "SELECT * FROM team";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["Team_ID"]) . '">' . htmlspecialchars($row["Team"]) . '</option>';
                    }
                }
                ?>
            </select>

            <label for="Year" id="Form_Label">Year:</label>
            <input type="number" id="Yeartext" name="Year" min="2000" max="3000" step="1" required>

            <label for="HostCity" id="Form_Label">Host City:</label>
            <select name="HostCity" id="HostCityList" required>
                <?php
                // Fetch host cities from the database
                $sql = "SELECT * FROM host_city";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["Host_City_ID"]) . '">' . htmlspecialchars($row["Host_City"]) . '</option>';
                    }
                }
                ?>
            </select>

            <label for="Sport" id="Form_Label">Sport:</label>
            <select name="Sport" id="SportList" required>
                <?php
                // Fetch sports from the database
                $sql = "SELECT * FROM sport";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["Sport_ID"]) . '">' . htmlspecialchars($row["Sport"]) . '</option>';
                    }
                }
                ?>
            </select>

            <label for="Event" id="Form_Label">Event:</label>
            <select name="Event" id="EventList" required>
                <?php
                // Fetch events from the database
                $sql = "SELECT * FROM event";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["Event_ID"]) . '">' . htmlspecialchars($row["Event"]) . '</option>';
                    }
                }
                ?>
            </select>

            <label for="Medal" id="Form_Label">Medal:</label>
            <select name="Medal" id="MedalList" required>
                <?php
                // Fetch medals from the database
                $sql = "SELECT * FROM medal";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["Medal_ID"]) . '">' . htmlspecialchars($row["Medal"]) . '</option>';
                    }
                }
                ?>
            </select>

            <input type="submit" value="Submit" id="submit_button">
        </form>
    </div>
</div>

			<!-- Local Storage for Color Blind Mode -->
		<script>
			function toggleColorBlindMode() {
				var body = document.getElementsByTagName("body")[0];
				body.classList.toggle("color-blind-mode");

				var isEnabled = body.classList.contains("color-blind-mode");
				localStorage.setItem("colorBlindModeEnabled", isEnabled);
			}

			document.addEventListener("DOMContentLoaded", function() {
				var isEnabled = localStorage.getItem("colorBlindModeEnabled") === "true";
				var body = document.getElementsByTagName("body")[0];
				if (isEnabled) {
					body.classList.add("color-blind-mode");
				}
			});
		</script>
	
<!-- Footer -->
<footer>
    <h5>Author: Amanda Henderson<br>
        Mailto: 21030@jhc.school.nz
    </h5>
</footer>

</body>
</html>
