<!DOCTYPE html>
<html lang="en">
	<head>
	  <meta charset="UTF-8" />
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	  
	<title>BrightPath</title>

	  <!-- Google Fonts -->
	  <link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet" />
	  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet" />

	  <!-- Favicon -->
	  <link rel="icon" type="image/x-icon" href="images/logo.png">

	  <style>
		body {
		  margin: 0;
		  font-family: 'Poppins', sans-serif;
		  background-image: url('images/background.jpg');
		  background-size: cover;
		  background-position: center;
		  background-repeat: no-repeat;
		  background-attachment: fixed;
		  text-align: center;
		}

		.container {
		  padding: 30px 20px;
		  max-width: 1200px;
		  margin: 0 auto;
		  padding-bottom: 80px;
		}

		/* Logo */
		.logo {
		  display: flex;
		  justify-content: center;
		  align-items: center;
		  gap: 10px;
		  margin-top: 40px;
		  margin-bottom: 20px;
		}

		.logo span {
		  font-family: 'Boldonse', sans-serif;
		  font-size: 100px;
		}

		.bulb-img {
		  height: 250px;
		  width: auto;
		}

		/* Back Button */
		.back-button {
		  display: inline-block;
		  margin: 20px;
		  font-size: 18px;
		  text-decoration: none;
		  color: #333;
		}

		/* Login Box */
		.login-box {
		  background-color: rgba(255, 255, 255, 0.3);
		  backdrop-filter: blur(10px);
		  -webkit-backdrop-filter: blur(10px);
		  border-radius: 10px;
		  width: 400px;
		  max-width: 90%;
		  margin: 0 auto;
		  padding: 40px;
		  box-shadow: 0 0 20px rgba(0,0,0,0.1);
		}

		.login-box h2 {
		  font-size: 40px;
		  margin-bottom: 30px;
		}

		.input-group {
		  display: flex;
		  align-items: center;
		  background: rgba(255, 255, 255, 0.8);
		  border-radius: 8px;
		  margin: 15px 0;
		  padding: 10px;
		}

		.input-group img {
		  width: 24px;
		  margin-right: 10px;
		}

		.input-group input {
		  border: none;
		  background: none;
		  outline: none;
		  font-size: 18px;
		  width: 100%;
		  font-family: 'Poppins', sans-serif;
		}

		.login-btn {
		  width: 100%;
		  padding: 12px;
		  font-size: 20px;
		  background-color: #D88BFF;
		  color: #fff;
		  border: none;
		  border-radius: 8px;
		  cursor: pointer;
		  margin-top: 20px;
		  transition: background-color 0.3s ease;
		}

		.login-btn:hover {
		  background-color: #F3C4FB;
		}

		.register-text {
		  margin-top: 20px;
		  font-size: 16px;
		}

		.register-text a {
		  text-decoration: underline;
		  color: #333;
		}

		footer {
		  font-size: 18px;
		  background-color: #F3C4FB;
		  padding: 15px;
		  margin-top: 60px;
		}

		/* Responsive */
		@media (max-width: 768px) {
		  .logo span {
			font-size: 60px;
		  }

		  .bulb-img {
			height: 150px;
		  }

		  .login-box h2 {
			font-size: 32px;
		  }

		  .input-group input {
			font-size: 16px;
		  }

		  .login-btn {
			font-size: 18px;
		  }
		}

		@media (max-width: 480px) {
		  .logo {
			flex-direction: column;
		  }

		  .logo span {
			font-size: 45px;
		  }

		  .bulb-img {
			height: 120px;
		  }

		  .login-box {
			padding: 20px;
		  }

		  .login-box h2 {
			font-size: 26px;
		  }

		  .login-btn {
			font-size: 16px;
			padding: 10px;
		  }

		  footer {
			font-size: 14px;
			padding: 10px;
		  }
		}
	  </style>
	</head>
	<body>
		  <div class="container">
			<!-- Logo -->
			<div class="logo">
			  <span>BrightPath</span>
			  <img src="images/logo.png" alt="logo" class="bulb-img">
			</div>

			<!-- Back Button -->
			<a href="index.html" class="back-button">← Back to opening page</a>

			<!-- Login Form -->
			<div class="login-box">
			  <h2>Login</h2>

			  <div class="input-group">
				<img src="images/user-icon.png" alt="User Icon">
				<input type="text" placeholder="Username">
			  </div>

			  <div class="input-group">
				<img src="images/lock-icon.png" alt="Password Icon">
				<input type="password" placeholder="Password">
			  </div>

			  <button class="login-btn">Login</button>

			  <p class="register-text">Don’t have an account? <a href="#">Register</a></p>
			</div>

			<!-- Footer -->
			<footer>BrightPath Learning System</footer>
		  </div>
	</body>
</html>
