<?php

	// PRINT A STATEMENT THAT INPUT HAS BEEN LOADED INTO THE DATABASE
	print("<h2>Loaded<h2>");

	// CONNECT TO OUR DATABASE
	require_once("connect.php");

	$Title = mysqli_real_escape_string($conn,$_REQUEST['Title']);
	$Type = $_REQUEST['bType'];
	$Competition = $_REQUEST['bCompetition'];
	$Teacher = $_REQUEST['bTeacher'];
	$Term = $_REQUEST['bTerm'];
	$Description = mysqli_real_escape_string($conn,$_REQUEST['bDescription']);

	$sql = "INSERT INTO Arts (Title, Type, Competition, Teacher, Term, Description)
			VALUES('$Title','$Type','$Competition','$Teacher','$Term','$Description')";

	if ($conn->query($sql) == TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	echo "<script>location.href='Events.php'</script>";
?>
