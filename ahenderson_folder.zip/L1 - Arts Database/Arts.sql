-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 28, 2023 at 12:03 AM
-- Server version: 8.0.34-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ahenderson_ArtsEvents`
--

-- --------------------------------------------------------

--
-- Table structure for table `Arts`
--

CREATE TABLE `Arts` (
  `ID` int NOT NULL,
  `Title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Competition` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Teacher in Charge` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Term` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(527) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `Arts`
--

INSERT INTO `Arts` (`ID`, `Title`, `Type`, `Competition`, `Teacher in Charge`, `Term`, `Description`) VALUES
(1, 'Sheilah Winn Shakespeare', 'stage play', 'yes', 'Mr Oudhoff', '1', 'The SGCNZ (Shakespeare Globe Centre New Zealand) 24 Regional University of Otago Sheilah Winn Shakespeare Festival is an annual, national festival in which  secondary-age students, from 11 to 19 years old.  Students perform 5 and 15-minute scenes from Shakespeare’s plays, set in any time, place, dress – though definitely in Shakespeare’s words. The Regional Festivals are scheduled between mid-March and mid-April.'),
(2, 'NZ Chamber Music Festival', 'Music contest', 'yes', 'Mrs Jarman', '2', 'The NZCT Chamber Music Contest is a the only national chamber contest of its kind in the world and has been running in NZ for over 50 years. District contests are held, followed by regional finals, and culminate with a national final.\n\n'),
(3, 'Big Sing', 'music', 'yes', 'Mrs Jarman', '2 & 3', 'The Big Sing is the national Secondary Schools\' Choral Festival and the Finale is the culmination of months of rehearsing and planning for all involved.'),
(4, 'Rockquest & Tangata Beats', 'music', 'yes', 'Mrs Jarman', '2 & 3', 'Smokefreerockquest is New Zealand’s only nationwide, live, original music, youth event. Now in its 33rd year, the series of over 40 events reaches audience numbers in excess of 10,000 every year. Founded in 1989 by music teachers Glenn Common and Pete Rainey, Smokefreerockquest has now become a New Zealand institution.'),
(5, 'NZ Secondary Schools Jazz Fesitval', 'music festival', 'yes', 'Mrs Jarman', '3', 'Southern Jam Youth Jazz Festival is an annual contest which showcases the very best emerging jazz players from secondary schools across New Zealand.'),
(6, 'Open Day', 'variety', 'no', 'All', '3', 'James Hargest College fosters all round development and the pursuit of excellence. On the open day, performing arts can be found in Drama displays, concert band, music bands, kapa haka, and much more.'),
(7, 'Junior Campus Production', 'musical production', 'no', 'Year 7/8 Teachers', '3', 'Junior campus take the stage in a musical production. The school has produced some of the most amazing musicals for example The Lion King Stage Production and The Wizard of Oz.'),
(8, 'Southland Secondary Schools Jazz Festival', 'music festival', 'yes', 'Mrs Jarman', '3 & 4', 'A secondary school jazz music competition that features schools from Southland and Central Otago.'),
(9, 'Year 9 - 10 Play', 'stage play', 'no', 'Ms Buist', '2', 'Year 9 and 10 students take the stage in a dramatic stage production to showcase their drama skills. In 2021, the Mystery at the Moor was a favourite of Invercargill.'),
(10, 'Senior Campus Production', 'musical production', 'no', 'Mrs Jarman', '2', 'Senior campus produce a major production every year. The school has produced some of the most amazing musicals from Fiddler on the Roof to the Pirates of Penzance and is accompanied by a live school orchestra. '),
(11, 'Showquest', 'performing arts', 'yes', 'Mr Oudhoff', '2', 'ShowQuest is a nationwide performing arts competition that evolved once Stage Challenge ended. It is a celebration of dance and drama, while also allowing opportunities for students to excel in live music and wearable art components too. Most performances tend to tell a narrative that evokes a relevant thematic message or at least a truth about ourselves.'),
(12, 'Concert Band', 'music', 'no', 'Mrs Jarman', '0', 'The concert band is made of talented musicians from Years 9-13. The band performs at a variety of school and community events.'),
(13, 'Interrobang', 'publication', 'no', 'Mrs Turner', '0', 'The Interrobang Magazine is a publication that has been put together by a group of Year 9-13 students who are interested in the writing, editing and publication processes. The Magazine comes out at the end of every term and contains extracts of novels, short stories, poems, song lyrics and comics. It has been barcoded by both the James Hargest Library and the Public Library and is contained as a link on both websites. New authors are always welcome. It is the perfect opportunity to get your ideas out and to get published!'),
(14, 'Ancora', 'music', 'no', 'Mrs Jarman', '0', 'Ancora is the Year 9-13 anually auditioned choir. The choir competes in national contests and performs at school and community events. '),
(15, 'Kapa Haka', 'performing arts', 'both', 'Mr Tane', '0', 'Kapa haka is the term for Māori performing arts and literally means to form a line (kapa) and dance (haka). It involves an emotional and powerful combination of song, dance and chanting. Kapa haka is performed by students at school, and during special events and festival.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Arts`
--
ALTER TABLE `Arts`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Arts`
--
ALTER TABLE `Arts`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
