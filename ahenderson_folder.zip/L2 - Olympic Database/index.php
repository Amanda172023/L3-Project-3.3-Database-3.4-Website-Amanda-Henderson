<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Olympics - Female Medal Winners</title>
		
		<!-- Stylesheets -->
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link href="css/color_blind_mode.css" rel="stylesheet" type="text/css">
		
		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;700&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
		<link href='https://fonts.googleapis.com/css?family=B612' rel='stylesheet'>
		
		<!-- Favicon -->
    	<link rel="icon" type="image/x-icon" href="images/logo.png">
	</head>	
	<body>
		
		<!-- Header -->
		<header class="home_header">
			<img src="images/logo.png" width="350" height="230" alt="Logo">
			<div class="home_header_text">
				<h1>Olympics</h1>
				<h2>Female Medal Winners</h2>
			</div>
		</header>

		<!-- Navigation -->
		<ul class="nav">
			<a class="activenav" href="index.php">Home</a>
			<a href="database_page.php">Database</a>
			<a href="form_page.php">Form</a>
		</ul>

		<!-- Color Blind Button -->
		<button class="color_blind_button" onclick="toggleColorBlindMode()">Toggle Color Blind Mode</button>

		<!-- Main Content -->
		<div class="content">
			<h2>Explore Olympic Glory: A Deep Dive into Medal-Winning Athletes</h2>
			<p>Welcome to our comprehensive database of Olympic athletes, where we celebrate the extraordinary achievements of competitors from around the world. Here, you can delve into the details of their journeys, performances, and triumphs on the grandest stage of all—the Olympic Games.</p>
		<div class="container">
			
			<!-- List of Athletes -->
			<div class="list">
				<ul>
					<li>Ragnhild Margrethe Aamodt from Norway, who clinched a Gold medal in Handball at the 2008 Beijing Olympics.</li>
					<li>Patimat Abakarova from Azerbaijan, who secured a Bronze in Taekwondo Flyweight at the 2016 Rio de Janeiro Olympics.</li>
					<li>Rebecca "Becky" Adlington, a remarkable swimmer from Great Britain, who won two Gold medals in the 400 and 800 meters Freestyle events at the 2008 Beijing Olympics and added two Bronze medals in the same events at the 2012 London Olympics.</li>
					<li>Nicola Virginia Adams from Great Britain, a boxing legend with Gold medals in Flyweight boxing from both the 2012 London and 2016 Rio de Janeiro Olympics.</li>
				</ul>
			</div>
			
			<!-- Images -->
			<div class="images">
				<img src="images/Ragnhild Margrethe Aamodt.jfif" alt="Ragnhild Margrethe Aamodt">
				<img src="images/Patimat Abakarova.jpg" alt="Patimat Abakarova">
				<img src="images/Nicola Virginia Adams.jpg" alt="Nicola Virginia Adams">
				<img src="images/Rebecca Becky Adlington.jfif" alt="Rebecca Becky Adlington">
			</div>
		</div>
			
			<br>
			<p>Our data not only covers their medal victories but also provides insights into their backgrounds, including age, height, weight, and the sports they excel in. Whether it’s diving, athletics, volleyball, or gymnastics, each athlete's story is a testament to their dedication and prowess.</p>
			<br>
			<p>Explore the heights of human performance and the spirit of competition. Each athlete’s profile showcases their path to Olympic success, reflecting years of hard work, perseverance, and a passion for their sport.</p>
			<p>Join us in celebrating these extraordinary individuals and their contributions to Olympic history. Discover their stories, be inspired by their journeys, and share in the triumphs of these world-class athletes.</p>
			<br>
			
			<!-- Link -->
			<a href="https://olympics.com/en/paris-2024">To find out more - click here</a>
		</div>
		
		<!-- Footer -->
		<footer>
			<h5>Author : Amanda Henderson <br>
				Mailto: 21030@jhc.school.nz
			</h5>
		</footer>

		<!-- Local Storage for Color Blind Mode -->
		<script>
			function toggleColorBlindMode() {
				var body = document.getElementsByTagName("body")[0];
				body.classList.toggle("color-blind-mode");

				var isEnabled = body.classList.contains("color-blind-mode");
				localStorage.setItem("colorBlindModeEnabled", isEnabled);
			}

			document.addEventListener("DOMContentLoaded", function() {
				var isEnabled = localStorage.getItem("colorBlindModeEnabled") === "true";
				var body = document.getElementsByTagName("body")[0];
				if (isEnabled) {
					body.classList.add("color-blind-mode");
				}
			});
		</script>
	</body>
</html>
