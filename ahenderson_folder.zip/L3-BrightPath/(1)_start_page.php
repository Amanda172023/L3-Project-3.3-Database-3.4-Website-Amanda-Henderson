<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>BrightPath - Start Page</title>
		
		<!-- Stylesheets -->
		<link href="css/style.css" rel="stylesheet" type="text/css">
		
		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Boldonse&display=swap" rel="stylesheet">
		<link href="" rel="stylesheet">
		<link href="" rel='stylesheet'>
		
		<!-- Favicon -->
    	<link rel="icon" type="image/x-icon" href="images/logo.png">
		
	</head>
	<body>
		<body style="background-image: url('images/background.jpg'); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100vh; width: 100%;">
		<header>
			<div class="top-container">
				<h1>BrightPath 
					<img src="images/logo.png" alt="logo">
				</h1>
			</div>
<div class="login-container">
  <div class="login-box">
    <h2>Login</h2>
    <form>
      <input type="text" placeholder="Username" required>
      <input type="password" placeholder="Password" required>
      <button type="submit">Log In</button>
    </form>
  </div>
</div>
		</header>
	
		<nav>
			
		</nav>
		
		<footer>
			
		</footer>
		
	</body>
</html>